package com.chrimar.ki

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val Bg = Color(0xFF090914)
private val Panel = Color(0xFF141426)
private val Purple = Color(0xFF7B3FF2)
private val Pink = Color(0xFFDB3BD9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChrimarKIApp() }
    }
}

@Composable
fun ChrimarKIApp() {
    var tab by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(listOf("ai" to "Hallo! 😊 Ek is Chrimar KI. Waarmee kan ek jou help?"))
    }
    var imageMade by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF241246), Bg)))
                .padding(top = 8.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("☰", color = Color.White, style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.width(12.dp))
                Text("🤖", style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("Chrimar KI", color = Color(0xFFD34CEB),
                        style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Jou KI metgesel", color = Color.LightGray)
                }
                Spacer(Modifier.weight(1f))
                Text("⚙", color = Color.White, style = MaterialTheme.typography.headlineMedium)
            }

            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    .fillMaxWidth()
                    .background(Panel, RoundedCornerShape(18.dp))
                    .padding(5.dp)
            ) {
                TabButton("💬 Gesels", tab == 0, Modifier.weight(1f)) { tab = 0 }
                TabButton("🎨 Maak prent", tab == 1, Modifier.weight(1f)) { tab = 1 }
            }

            if (tab == 0) {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
                    reverseLayout = false,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 14.dp)
                ) {
                    items(messages) { (role, text) ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement =
                            if (role == "user") Arrangement.End else Arrangement.Start) {
                            Surface(
                                color = if (role == "user") Purple else Panel,
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.widthIn(max = 330.dp)
                            ) { Text(text, Modifier.padding(14.dp), color = Color.White) }
                        }
                    }
                }

                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = message, onValueChange = { message = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Tik jou boodskap...") },
                        shape = RoundedCornerShape(24.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (message.isNotBlank()) {
                                val sent = message.trim()
                                messages = messages + ("user" to sent) +
                                    ("ai" to "Ek het jou boodskap ontvang. 😊 Die regte KI-koppeling kan nou hier antwoord.")
                                message = ""
                            }
                        },
                        shape = RoundedCornerShape(50)
                    ) { Text("➤") }
                }
            } else {
                Column(
                    Modifier.weight(1f).fillMaxWidth().padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Maak jou eie prent", style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Beskryf wat jy wil hê die KI moet maak.",
                        color = Color.LightGray, modifier = Modifier.padding(top = 5.dp))
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = prompt, onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp),
                        placeholder = { Text("Byvoorbeeld: 'n Leeuwelpie in die sneeu...") },
                        shape = RoundedCornerShape(18.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { imageMade = prompt.isNotBlank() },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                    ) { Text("✨ Maak prent", fontWeight = FontWeight.Bold) }

                    if (imageMade) {
                        Spacer(Modifier.height(18.dp))
                        Box(
                            Modifier.fillMaxWidth().height(300.dp)
                                .background(
                                    Brush.linearGradient(listOf(Purple, Pink)),
                                    RoundedCornerShape(20.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("🎨", style = MaterialTheme.typography.displayLarge)
                                Text("Jou prent sal hier verskyn",
                                    color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Koppel die KI-bediener om dit werklik te genereer.",
                                    color = Color.White.copy(alpha = .8f))
                            }
                        }
                    }
                }
            }

            NavigationBar(containerColor = Color(0xFF0D0D19)) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                    icon = { Text("💬") }, label = { Text("Gesels") })
                NavigationBarItem(selected = false, onClick = {},
                    icon = { Text("🕘") }, label = { Text("Geskiedenis") })
                NavigationBarItem(selected = false, onClick = {},
                    icon = { Text("👤") }, label = { Text("Profiel") })
            }
        }
    }
}

@Composable
fun TabButton(text: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick, modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (active) Purple else Color.Transparent,
            contentColor = Color.White
        )
    ) { Text(text, fontWeight = FontWeight.Bold) }
}
