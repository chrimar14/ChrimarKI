# Chrimar KI – Volledige Android-projek

Hierdie projek bevat die Android-UI vir:
- 💬 Gesels
- 🎨 Maak prent
- 🕘 Geskiedenis-knoppie
- 👤 Profiel-knoppie
- Donker/persoonlike Chrimar KI-ontwerp
- Android Internet-permissie

## Bou

Maak die projek in Android Studio oop en laat Gradle die dependencies aflaai.
Kies daarna **Build > Build APK(s)**.

## Belangrik oor die KI

Die app se UI is gereed, maar 'n produksie-app moet aan 'n veilige backend gekoppel word vir KI-klets en beeldgenerering.

**Moenie 'n OpenAI API-sleutel direk in die Android APK plaas nie.**
Gebruik 'n backend en laat die backend met die API kommunikeer.
